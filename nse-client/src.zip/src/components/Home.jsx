import React from 'react';
import '../styles/Header.css';

const Home = () => {
  return <></>;
};

export default Home;
